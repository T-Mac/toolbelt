module Heroku
  VERSION = "2.4.2"
end
